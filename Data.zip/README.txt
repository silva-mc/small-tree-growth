R code and data for "Small understory trees increase growth following sustained drought in the Amazon"

Input data metadata

Cax_Silva_M_data_v2: stem diameter (DBH) timeseries data (individual level)
plot: Plot (Control, TFE Throughfall Exclusion)
subplot: 100 m2 subplot
id: Tree unique identifier
dbh: Stem diameter at 1.30 m (DBH; cm)
dbh_init: Initial (2017) diameter at the breast height (cm)
date: Date (YYYY/MM/DD)
obs: Observations

Cax_Silva_M_data_rgr_v2: Stem increment data (individual level)
plot: Plot (Control, TFE Throughfall Exclusion)
subplot: 100 m2 subplot
family: Family
genus: Genus
search.str: Species
rgr: Stem increment rate (cm/year)
dbh_init: Initial (2017) diameter at the breast height (cm)

Cax_Silva_M_data_rgr_avg_v2: Stem increment data (species level)
plot: Plot (Control, TFE Throughfall Exclusion)
family: Family
genus: Genus
search.str: Species
rgr: Stem increment rate (cm/year)

Cax_Silva_M_data_subp_v2: Stem increment data (subplot level)
plot: Plot (Control, TFE Throughfall Exclusion)
subplot: 100 m2 subplot
tree_numbe: Number of large trees (DBH > 10 cm; individual/subplot)
tree_densi: Density of large trees (DBH > 10 cm; individual/m2)
tree_ba_m2_m2: Basal area of large trees (DBH > 10 cm; m2/m2)
sapli_numbe: Number of small trees (DBH 1-10 cm; individual/subplot)
sapli_densi: Density of small trees (DBH 1-10 cm; individual/m2)
sapli_ba_m2_m2: Basal area of small trees (DBH 1-10 cm; m2/m2)
rgr_mean: Stem increment rate (cm/year)

Cax_Silva_M_data_subp_long_v2: Species richness and individual density (subplot level)
plot: Plot (Control, TFE Throughfall Exclusion)
subplot: 100 m2 subplot
year: Year
rich: Small tree species richness (species/subplot)
stem_numb: Small tree individual density (tree/subplot)

Cax_Silva_M_data_trai_pca_v2: 
plot: Plot (Control, TFE Throughfall Exclusion)
family: Family
genus: Genus
search.str: Species
rgr: Stem increment rate (cm/year)
dbh: Diameter at the breast height (cm)
vcmax: Maximum rate of Rubisco carboxylation (umol/m2/s)
jmax: Maximum electron transport rate (umol/m2/s)
rleaf: Leaf dark respiration rate (umol/m2/s)
gsmin: Leaf minimum conductance (mmol/m2/s)
nmass: Leaf nitrogen content (g/kg)
pmass: Leaf phosphorus content (g/kg)
lma: Leaf mass per area (g/m2)
lth: Leaf thickness (mm)
wd: Wood density (g/cm3)
pdwp: Predawn leaf water potential (MPa)
mdwp: Midday leaf water potential (MPa)
p50: Water potential at which 50% of conductivity loss (MPa)
p88: Water potential at which 88% of conductivity loss (MPa)
ksmax: Maximum xylem-specific hydraulic conductivity (mol/m2/s/MPa)
plc: Percentage loss of xylem conductivity (%)
lasa: Leaf-to-sapwood area ratio (-)
PC1...PC16: Principal components 1 to 16

Cax_Silva_M_pca_loadings_v2: PC loadings
Cax_Silva_M_pca_scores_v2: PC scores
Cax_Silva_M_pca_v2: PCA RDS object
